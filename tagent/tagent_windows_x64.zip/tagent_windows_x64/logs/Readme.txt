logs for windows
