#!/usr/bin/perl
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "$FindBin::Bin/../lib/perl-lib/lib/perl5";

use strict;
use warnings;

package TagentManager;

use English qw( -no_match_vars );
use Errno qw(ETIMEDOUT EWOULDBLOCK EINTR);
use HTTP::Tiny;
use IO::Socket::INET;
use IO::Select;
use Net::Netmask;

use JSON;
use TagentClient;
use Crypt::RC4;
use Config;
use File::Basename;
use POSIX qw(:sys_wait_h WNOHANG setsid uname);
use Distribution;

sub _rc4_encrypt_hex ($$) {
    my ( $key, $data ) = ( $_[0], $_[1] );
    return join( '', unpack( 'H*', RC4( $key, $data ) ) );
}

sub _rc4_decrypt_hex ($$) {
    my ( $key, $data ) = ( $_[0], $_[1] );
    return RC4( $key, pack( 'H*', $data ) );
}

sub randPass {
    my ($self) = @_;

    my @chars = ( 'A' .. 'Z', 'a' .. 'z', '0' .. '9' );
    my $pass  = '';

    for ( my $i = 0 ; $i < 16 ; $i++ ) {
        $pass = $pass . $chars[ rand @chars ];
    }

    return $pass;
}

sub hashStrToInt {
    my ( $self, $str ) = @_;

    my $hashVal = unpack( "%32N*", $str ) % 65535;
    return $hashVal;
}

sub getFileContent {
    my ( $self, $filePath ) = @_;
    my $content;

    if ( -f $filePath ) {
        my $size = -s $filePath;
        my $fh   = new IO::File("<$filePath");

        if ( defined($fh) ) {
            $fh->read( $content, $size );
            $fh->close();
        }
    }

    return $content;
}

sub isIgnoreNetIf {
    my ( $self, $ifName ) = @_;

    my $ignore = 0;

    my $ifTypeNum = int( $self->getFileContent("/sys/class/net/$ifName/type") );
    if ( $ifTypeNum == 1 ) {
        if ( -e "/sys/class/net/$ifName/bridge" or -e "/sys/class/net/$ifName/brport/bridge" ) {

            #bridge or bridge port
            $ignore = 1;
        }
        elsif ( -e "/sys/class/net/$ifName/tun_flags" ) {

            #tun tap
            $ignore = 1;
        }
        elsif ( -e "/proc/net/vlan/$ifName" ) {

            #vlan
            $ignore = 1;
        }
        elsif ( $ifName =~ /^dummy/ and -e "/sys/devices/virtual/net/$ifName" ) {

            #dummy
            $ignore = 1;
        }
        elsif ( -f "/sys/class/net/$ifName/address" ) {
            my $macAddr = $self->getFileContent("/sys/class/net/$ifName/address");
            if ( $macAddr eq '00:00:00:00:00:00' ) {
                $ignore = 1;
            }
        }
    }
    else {
        $ignore = 1;
    }

    return $ignore;
}

sub getIpByProcForLinux {
    my ($self) = @_;

    #Iface  Destination     Gateway         Flags   RefCnt  Use     Metric  Mask            MTU     Window  IRTT
    ##ens160 00000000        0100A8C0        0003    0       0       100     00000000        0       0       0
    #ens160 0000A8C0        00000000        0001    0       0       100     00FEFFFF        0       0       0

    my $fh = IO::File->new("</proc/net/route");

    my %nicsMap = ();
    if ( defined($fh) ) {
        while ( my $line = $fh->getline() ) {
            $line =~ s/^\s+|\s+$//g;
            if ( $line ne '' ) {
                my @fields = split( /\s+/, $line );
                if ( $#fields == 10 and $fields[2] eq '00000000' ) {
                    my $name      = $fields[0];
                    my $isVirtual = 0;
                    if ( $self->isIgnoreNetIf($name) ) {
                        $isVirtual = 1;
                    }

                    if ( $isVirtual == 0 ) {

                        #my $hex_ip = "0100A8C0";  # 你的16进制IP地址
                        #my @octets = reverse(unpack("C*", pack("H*", $hex_ip)));
                        my $nicInfo = {
                            name        => $name,
                            isVirtual   => $isVirtual,
                            destination => unpack( 'N', pack( 'I', hex( $fields[1] ) ) ),
                            mask        => unpack( 'N', pack( 'I', hex( $fields[7] ) ) )
                        };

                        #记录掩码最长的
                        my $oldNicInfo = $nicsMap{$name};
                        if ( not defined($oldNicInfo) ) {
                            $nicsMap{$name} = $nicInfo;
                        }
                        elsif ( int( $nicInfo->{mask} ) > int( $oldNicInfo->{mask} ) ) {
                            $nicsMap{$name} = $nicInfo;
                        }
                    }
                }
            }
        }
        $fh->close();
    }

    my %ipv4AddrsMap = ();
    my %ipv6AddrsMap = ();
    $fh = IO::File->new("/proc/net/fib_trie");
    if ( defined($fh) ) {
        my $preLine;
        while ( my $line = $fh->getline() ) {
            if ( $line =~ /32 host LOCAL/ ) {
                if ( $preLine =~ /(\d+\.\d+\.\d+\.\d+)$/ ) {
                    my $ipAddr = $1;
                    if ( $ipAddr !~ /^127/ ) {
                        $ipv4AddrsMap{$ipAddr} = 1;
                    }
                }
                elsif ( $preLine =~ /([\w:]+)$/ ) {
                    my $ipAddr = $1;
                    if ( $ipAddr !~ '^::1' ) {
                        $ipv6AddrsMap{$ipAddr} = 1;
                    }
                }
            }
            $preLine = $line;
        }
        $fh->close();
    }

    #按照netmask长短排序（长的排前面）
    my @nicNames = sort { int( $nicsMap{$b}->{mask} ) <=> int( $nicsMap{$a}->{mask} ) } keys(%nicsMap);

    my @ipStringArray = ();
    foreach my $ipv4 ( keys(%ipv4AddrsMap) ) {
        my $ip = unpack( 'N', pack( 'C4', split( /\./, $ipv4 ) ) );
        foreach my $nicName (@nicNames) {
            my $nicInfo = $nicsMap{$nicName};

            if ( int( $ip & $nicInfo->{mask} ) == int( $nicInfo->{destination} ) ) {
                push( @ipStringArray, $ipv4 );
                last;
            }
        }
    }

    return \@ipStringArray;
}

sub collectIp {
    my ($self) = @_;

    my @ipStringArray = ();
    my $allIps        = {};
    my $allIpv6s      = {};

    if ( $self->{ostype} eq 'windows' ) {
        my $ipconfigOut = `ipconfig /all | findstr "IP"`;
        while ( $ipconfigOut =~ /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/g ) {
            my $ipAddr = "$1.$2.$3.$4";
            if ( $ipAddr !~ /^127/ ) {
                if ( not defined( $allIps->{$ipAddr} ) ) {
                    push( @ipStringArray, $ipAddr );
                }
                $allIps->{$ipAddr} = 1;
            }
        }
        while ( $ipconfigOut =~ /([0-9a-fA-F:]+)/g ) {
            my $ipAddr = $1;
            if ( $ipAddr !~ '^::1' ) {

                #IPV6暂时没有放到采集结果中
                $allIps->{$ipAddr} = 1;
            }
        }
    }
    else {
        my @nicInfoList = `ip addr 2>/dev/null`;
        if ( $? != 0 ) {
            @nicInfoList = `ifconfig -a 2>/dev/null`;
        }
        if ( $? == 0 ) {
            my $currentNic;
            my $isVirtualNic = 0;
            my $nicInfoCount = scalar(@nicInfoList);
            for ( my $i = 0 ; $i < $nicInfoCount ; $i++ ) {
                my $line = $nicInfoList[$i];
                if ( $line =~ /^\d+:\s+(\S+):/ or $line =~ /^(\w+):/ ) {
                    $isVirtualNic = 0;
                    $currentNic   = $1;
                    $currentNic =~ s/\@.*$//;
                    if ( $self->isIgnoreNetIf($currentNic) ) {
                        $isVirtualNic = 1;
                    }
                }

                if ( $isVirtualNic == 1 ) {
                    next;
                }

                if ( $line =~ /^\s*inet\s(\d+\.\d+\.\d+\.\d+)/ ) {
                    my $ipAddr = $1;
                    if ( $ipAddr !~ /^127/ ) {
                        if ( not defined( $allIps->{$ipAddr} ) ) {
                            push( @ipStringArray, $ipAddr );
                        }
                        $allIps->{$ipAddr} = 1;
                    }
                }
                elsif ( $line =~ /^\s*inet6\s([\w:]+)/ ) {
                    my $ipAddr = $1;
                    if ( $ipAddr !~ '^::1' ) {

                        #IPV6暂时没有放到采集结果中
                        $allIpv6s->{$ipAddr} = 1;
                    }
                }
            }
        }
        elsif ( -e "/proc/net/fib_trie" ) {
            my $ipArray = $self->getIpByProcForLinux();
            @ipStringArray = @$ipArray;
        }
    }

    my $ipString = join( ',', @ipStringArray );
    return $ipString;
}

sub collectOsInfo {
    my ($self) = @_;

    my $tagent = $self->{tagent};

    my $osInfo = {};

    my $hostName = `hostname`;
    $hostName =~ s/^\s*|\s*$//g;
    $osInfo->{hostname} = $hostName;

    my @uname     = uname();
    my $osType    = $uname[0];
    my $release   = $uname[2];
    my $osVersion = $uname[3];
    my $osbit     = $uname[4];
    if ( $osType =~ /Windows/i ) {
        $osType = 'windows';
    }
    $osType = lc($osType);
    $osInfo->{osType} = $osType;

    my $user = 'root';
    if ( $osType eq 'windows' ) {
        $user = 'administrator';

        my $caption = `wmic os get caption 2>nul | findstr /i /v caption`;
        $caption =~ s/[^[:ascii:][:print:]]//g;
        $caption =~ s/\?\s*/ /g;
        $caption =~ s/^\s*|\s*$//g;

        $osVersion =~ s/[^[:ascii:][:print:]]//g;
        $osVersion =~ s/^\s*|\s*$//g;
        $osVersion = $caption . '_' . $osVersion;
    }
    else {
        $user = getpwuid($<);
        if ( not defined($user) or $user eq '' ) {
            $user = 'root';
        }
        if ( $osType eq 'aix' ) {
            $osVersion = `oslevel`;
            $osVersion =~ s/^\s+|\s+$//g;
            $osbit = `bootinfo -K`;
            if ( $osbit =~ /64/ ) {
                $osbit = 'ppc64';
            }
            else {
                $osbit = 'ppc32';
            }
        }
        else {
            $osbit = $uname[4];
            eval {
                my $dist = Distribution->new();

                my $distName = $dist->distribution_name();
                if ( defined($distName) ) {
                    my $version = $dist->distribution_version();
                    if ( not defined($version) ) {
                        $version = '';
                    }
                    $osVersion = "${distName}${version}_${release}";
                }
            };
            if ($@) {
                $tagent->log("WARN: get os distribute info failed, $@\n");
            }
        }
    }
    $osInfo->{osUser}    = $user;
    $osInfo->{osbit}     = $osbit;
    $osInfo->{osVersion} = $osVersion;

    my $ipString = $self->collectIp();
    $osInfo->{ipString} = $ipString;

    my $ipHashVal = $self->hashStrToInt($ipString);
    $self->{ipHashVal} = $ipHashVal;

    my $mgmtIp = $self->getMgmtIp($ipString);
    if ( defined($mgmtIp) and $mgmtIp ne '' ) {
        $tagent->log("INFO: get tagent manage subnet register ip: $mgmtIp .\n");
        $osInfo->{mgmtIp} = $mgmtIp;
    }

    $self->{osInfo} = $osInfo;

    return $osInfo;
}

# tagent register , succeed return 1
sub new {
    my ( $type, $tagent ) = @_;

    my $self = {};
    bless( $self, $type );

    $self->{tagent} = $tagent;

    my $config        = $tagent->{config};
    my $confFile      = $tagent->{confFile};
    my $myKey         = $tagent->{MY_KEY};
    my $_dont_inherit = $tagent->{_dont_inherit};

    my @uname  = uname();
    my $ostype = $uname[0];
    if ( $ostype =~ /Windows/i ) {
        $ostype = 'windows';
    }
    $ostype = lc($ostype);
    $self->{ostype} = $ostype;

    my $confDir         = dirname($confFile);
    my $appsConfFile    = "$confDir/managed/apps.json";
    my $appsConfMd5File = "$confDir/managed/apps.json.md5";

    if ( -f $appsConfFile ) {
        eval {
            my $appsJson = $self->getFileContent($appsConfFile);
            my $appsConf = from_json($appsJson);

            foreach my $app ( keys(%$appsConf) ) {

                my $appConf     = $appsConf->{$app};
                my $defaultConf = $appConf->{default};
                my $myOsConf    = $appConf->{$ostype};

                if ( not defined($myOsConf) ) {
                    $appConf->{$ostype} = $defaultConf;
                }
                else {
                    foreach my $key ( keys(%$defaultConf) ) {
                        if ( not defined( $myOsConf->{$key} ) ) {
                            $myOsConf->{$key} = $defaultConf->{$key};
                        }
                    }
                }
            }
            $self->{appsConf} = $appsConf;

            my $appsJsonMd5 = $self->getFileContent($appsConfMd5File);
            $self->{appsConfMd5} = $appsJsonMd5;
        };
        if ($@) {
            $tagent->log("WARN: parse json file:$appsConfFile failed.\n");
        }
    }

    $self->{confDir}       = $confDir;
    $self->{config}        = $config;
    $self->{confFile}      = $confFile;
    $self->{MY_KEY}        = $myKey;
    $self->{_dont_inherit} = $_dont_inherit;
    $self->{appsStatus}    = {};
    $self->{loopInterval}  = 10;
    $self->{confChanged}   = 0;

    $self->{regProxyGroups}   = [];
    $self->{regProxyGroupIds} = [];
    $self->{connsMap}         = {};

    $self->{registered} = 0;

    my $mainConf = $config->{_};

    my @tagentIds = ();
    $self->{tagentIds} = \@tagentIds;

    my $defaultTenant = $mainConf->{tenant};
    my $tenants       = [];
    my $proxyGroups   = [];
    my $proxyGroupIds = [];

    my @registerFlags = ();
    $self->{registerFlags} = \@registerFlags;

    my $registerAddress = $mainConf->{'proxy.registeraddress'};
    if ( defined($registerAddress) and $registerAddress ne '' ) {
        $registerAddress =~ s/[\s;]*;[\s;]*/;/g;
        my $idx = 0;
        for my $regAddr ( split( /\s*;\s*/, $registerAddress ) ) {
            if ( defined($regAddr) and $regAddr ne '' ) {
                push( @registerFlags,  0 );
                push( @tagentIds,      '' );
                push( @$proxyGroupIds, $idx + 1 );
                push( @$proxyGroups,   '' );

                if ( $regAddr =~ /\Wtenant=([\w]+)/ ) {
                    push( @$tenants, $1 );
                }
                else {
                    push( @$tenants, $defaultTenant );
                }
            }
            $idx = $idx + 1;
        }
    }

    $self->{hasTagentId} = 0;
    my $tagentIdsConf = $mainConf->{'tagent.id'};
    if ( defined($tagentIdsConf) and $tagentIdsConf ne '' ) {
        $tagentIdsConf =~ s/[\s;]*;[\s;]*/;/g;
        my $idx = 0;
        for my $tagentId ( split( /\s*;\s*/, $tagentIdsConf ) ) {
            $self->{hasTagentId} = 1;
            $tagentIds[$idx]     = $tagentId;
            $idx                 = $idx + 1;
        }
    }

    my $proxyGroupsConf = $mainConf->{'proxy.group'};
    if ( defined($proxyGroupsConf) and $proxyGroupsConf ne '' ) {
        $proxyGroupsConf =~ s/[\s;]*;[\s;]*/;/g;
        my $idx = 0;
        foreach my $proxyGroup ( split( /\s*;\s*/, $proxyGroupsConf ) ) {
            $$proxyGroups[$idx] = $proxyGroup;
        }
        $idx = $idx + 1;
    }

    my $proxyGroupIdsConf = $mainConf->{'proxy.group.id'};
    if ( defined($proxyGroupIdsConf) and $proxyGroupIdsConf ne '' ) {
        $proxyGroupIdsConf =~ s/[\s;]*;[\s;]*/;/g;
        my $idx = 0;
        foreach my $proxyGroupId ( split( /\s*;\s*/, $proxyGroupIdsConf ) ) {
            $$proxyGroupIds[$idx] = $proxyGroupId;
        }
        $idx = $idx + 1;
    }

    $self->{proxyGroups}   = $proxyGroups;
    $self->{proxyGroupIds} = $proxyGroupIds;
    $self->{tenants}       = $tenants;

    $self->{osInfo} = $self->collectOsInfo();

    return $self;
}

sub getVersion {
    return '1.6.0';
}

sub _getWinScriptExt {
    my ( $self, $interpreter ) = @_;

    my $extName;
    if ( not defined($interpreter) ) {
        $extName = '.bat';
    }
    elsif ( $interpreter =~ /powershell/i ) {
        $extName = '.ps1';
    }
    elsif ( $interpreter =~ /perl/i ) {
        $extName = '.pl';
    }
    elsif ( $interpreter =~ /cscript/i ) {
        $extName = '.vbs';
    }
    elsif ( $interpreter =~ /python/i ) {
        $extName = '.py';
    }
    elsif ( $interpreter =~ /cmd/i ) {
        $extName = '.bat';
    }
    else {
        $extName = '.bat';
    }

    return $extName;
}

sub getMgmtIp {
    my ( $self, $ipstr ) = @_;
    my $config = $self->{config}->{_};
    my $tagent = $self->{tagent};

    my $registerSubnet = $config->{'register.subnet'};
    my $mgmtIp;
    if ( defined($registerSubnet) and $registerSubnet ne '' ) {
        my @subnets = split( /,/, $registerSubnet );
        foreach my $subnet (@subnets) {
            if ( defined($mgmtIp) and $mgmtIp ne '' ) {
                last;
            }
            my $subnet_network = Net::Netmask->safe_new($subnet);
            my @ips            = split( /,/, $ipstr );
            foreach my $ip (@ips) {

                #$tagent->log("Debug: check ip $ip in manage subnet $registerSubnet .\n");
                if ( $subnet_network->match($ip) ) {
                    $mgmtIp = $ip;
                    last;
                }
            }
        }
    }
    return $mgmtIp;
}

sub doRegister {
    my ( $self, $seqNo, $subRegAddr, $postData ) = @_;

    my $tagent     = $self->{tagent};
    my $config     = $self->{config}->{_};
    my $ipHashVal  = $self->{ipHashVal};
    my $tagentIds  = $self->{tagentIds};
    my $myTagentId = $$tagentIds[$seqNo];
    my $tenants    = $self->{tenants};

    $postData->{tenant} = $$tenants[$seqNo];
    if ( defined($myTagentId) and $myTagentId ne '' ) {
        $postData->{tagentId} = $myTagentId;
    }
    else {
        $postData->{tagentId} = $$tagentIds[0];
    }

    my @proxyAddresses = split( /\s*,\s*/, $subRegAddr );
    if ( scalar(@proxyAddresses) > 1 ) {
        my $startIdx       = $ipHashVal % scalar(@proxyAddresses);
        my @headProxyAddrs = splice( @proxyAddresses, 0, $startIdx );
        push( @proxyAddresses, @headProxyAddrs );
    }

    my $newCred = $postData->{credential};
    if ( defined($newCred) and $config->{'credential'} ne $newCred ) {
        $config->{'credential'} = $newCred;
        $self->{confChanged}    = 1;
    }

    my $registSucceed = 0;

    foreach my $proxyAddress (@proxyAddresses) {
        $tagent->log("INFO: try to register, register address is $proxyAddress...\n");
        $tagent->log( "INFO: Send register data:" . to_json($postData) . "\n" );
        my $http     = HTTP::Tiny->new( timeout => 15 );
        my $response = $http->post(
            $proxyAddress => {
                content => to_json($postData),
                headers => { "Content-Type" => "application/json", "User-Agent" => "Mozilla/5.0" },
            },
        );
        if ( $response->{status} == 200 ) {
            eval {
                my $retval    = from_json( $response->{content} );
                my $regStatus = $retval->{"Status"};

                $tagent->log( "INFO: Register response:" . $response->{content} . "\n" );
                if ( defined($regStatus) and ( $regStatus eq "OK" or $regStatus eq "SUCCEED" ) ) {
                    my @group        = ();
                    my $data         = $retval->{"Data"};
                    my $tagentId     = $data->{"tagentId"};
                    my $proxyGroupId = $data->{"proxyGroupId"};
                    my @proxyList    = @{ $data->{'proxyList'} };
                    foreach my $proxy (@proxyList) {
                        my $address = $proxy->{"ip"} . ":" . $proxy->{"port"};
                        push( @group, $address );
                    }
                    my $proxyGroup = join( ',', @group );

                    if ( not defined($myTagentId) or $tagentId ne $myTagentId ) {
                        $myTagentId          = $tagentId;
                        $$tagentIds[$seqNo]  = $tagentId;
                        $self->{confChanged} = 1;
                    }

                    if ( scalar(@group) > 0 ) {
                        my $regProxyGroups   = $self->{regProxyGroups};
                        my $regProxyGroupIds = $self->{regProxyGroupIds};
                        push( @$regProxyGroups, $proxyGroup );

                        if ( not defined($proxyGroupId) or $proxyGroupId eq '' ) {
                            $proxyGroupId = scalar(@$regProxyGroups);
                        }
                        push( @$regProxyGroupIds, $proxyGroupId );
                    }

                    $registSucceed = 1;
                    my $registerFlags = $self->{registerFlags};
                    $$registerFlags[$seqNo] = 1;
                    $self->{hasTagentId} = 1;

                    $tagent->log("INFO: Registry success, tagent id:$tagentId, proxy group:$proxyGroup.\n");
                }
                else {
                    $tagent->log( "ERROR: Tagent register failed:" . $retval->{'Message'} . "\n" );
                }
            };
            if ($@) {
                $tagent->log( "ERROR: Tagent register return:" . $response->{content} . "\n" );
                $tagent->log("ERROR: Tagent register failed:$@\n");
            }
            else {
                if ( $registSucceed eq 1 ) {
                    last;
                }
            }
        }
    }

    $tagent->_purgeLog();
    return $registSucceed;
}

sub _detectProxyGroupChanged {
    my ($self) = @_;
    my $config = $self->{config}->{_};

    my $tagentIds     = $self->{tagentIds};
    my $tagentIdsConf = join( ';', @$tagentIds );
    $config->{'tagent.id'} = $tagentIdsConf;

    my $regProxyGroups     = $self->{regProxyGroups};
    my $regProxyGroupsConf = join( ';', @$regProxyGroups );
    my $proxyGroups        = $self->{proxyGroups};
    my $proxyGroupsConf    = join( ';', @$proxyGroups );
    if ( $regProxyGroupsConf ne $proxyGroupsConf ) {
        $config->{'proxy.group'} = $regProxyGroupsConf;
        $self->{proxyGroups}     = $regProxyGroups;
        $self->{confChanged}     = 1;
    }

    my $regProxyGroupIds     = $self->{regProxyGroupIds};
    my $regProxyGroupIdsConf = join( ';', @$regProxyGroupIds );
    if ( not defined($regProxyGroupIdsConf) ) {
        @$regProxyGroupIds = ();
        for ( my $i = 0 ; $i < scalar(@$proxyGroups) ; $i++ ) {
            push( @$regProxyGroupIds, $i );
        }
    }

    my $proxyGroupIds     = $self->{proxyGroupIds};
    my $proxyGroupIdsConf = join( ';', @$proxyGroupIds );
    if ( $proxyGroupIdsConf ne $regProxyGroupIdsConf ) {
        $config->{'proxy.group.id'} = $regProxyGroupIdsConf;
        $self->{proxyGroupIds}      = $regProxyGroupIds;
        $self->{confChanged}        = 1;
    }

    return;
}

sub register {
    my ($self) = @_;

    if ( $self->{registered} == 1 ) {
        return;
    }

    my $tagent          = $self->{tagent};
    my $config          = $self->{config}->{_};
    my $registerAddress = $config->{'proxy.registeraddress'};

    my $osInfo = $self->{osInfo};
    my $osUser = $osInfo->{osUser};

    if ( defined($registerAddress) and $registerAddress ne '' ) {
        $registerAddress =~ s/[\s;]*;[\s;]*/;/g;

        my $tagentVersion = getVersion();
        my $credential    = $config->{'credential'};
        my $port          = $config->{'listen.port'};

        my $postData = {
            user       => $osInfo->{osUser},
            port       => $port,
            ipString   => $osInfo->{ipString},
            name       => $osInfo->{hostname},
            version    => $tagentVersion,
            osType     => $osInfo->{osType},
            osVersion  => $osInfo->{osVersion},
            osbit      => $osInfo->{osbit},
            mgmtIp     => $osInfo->{mgmtIp},
            credential => $credential
        };

        my $authKeyEncrypted;
        my $newPass;
        if ( $self->{hasTagentId} != 1 ) {
            $newPass                = $self->randPass();
            $authKeyEncrypted       = '{ENCRYPTED}' . _rc4_encrypt_hex( $self->{MY_KEY}, $newPass );
            $postData->{credential} = $authKeyEncrypted;
        }

        my $registerFlags = $self->{registerFlags};
        my @allRegAddrs   = split( /\s*;\s*/, $registerAddress );

        while (1) {
            for ( my $i = 0 ; $i <= $#allRegAddrs ; $i++ ) {
                my $subRegAddr = $allRegAddrs[$i];
                if ( $$registerFlags[$i] != 1 ) {
                    if ( $self->doRegister( $i, $subRegAddr, $postData ) ) {
                        $$registerFlags[$i] = 1;
                    }
                }
            }
            if ( $self->{hasTagentId} == 1 ) {
                last;
            }
            sleep(3);
        }

        my $registered = 1;
        for my $regFlag (@$registerFlags) {
            if ( $regFlag == 0 ) {
                $registered = 0;
            }
        }
        $self->{registered} = $registered;

        $self->_detectProxyGroupChanged();

        if ( $self->{confChanged} == 1 ) {
            $tagent->log("ERROR: Config changed, try to update config file...\n");
            if ( not $self->{config}->write( $self->{confFile} ) ) {
                $tagent->log("ERROR: Update config file failed after registered:$!\n");

                #die("Update config file failed after registered:$!\n");
            }
            else {
                $self->{confChanged} = 0;
            }
            $tagent->log("ERROR: Config file updated.\n");
        }

        return $newPass;
    }
    else {
        $tagent->log("INFO: Registry Address is empty, running in standalone mode.\n");
        return;
    }
}

#connect with proxy
sub getConnection {
    my ( $self, $proxyGroup ) = @_;

    my $config = $self->{config}->{_};
    my $tagent = $self->{tagent};

    my $group;
    if ( defined($proxyGroup) ) {
        $group = $proxyGroup;
    }
    else {
        $group = $config->{'proxy.group'};
    }

    my $listenAddr = $config->{'listen.addr'};

    my $socket;

    if ( defined($group) and $group ne '' ) {
        my $socketType = SOCK_STREAM;
        if ( $self->{ostype} ne 'windows' ) {
            eval(q{$socketType = Socket::SOCK_STREAM | Socket::SOCK_CLOEXEC;});
        }

        my @proxyList  = split( /,/, $group );
        my $proxyCount = scalar(@proxyList);

        #根据tagentId的值进行proxy的优先选择
        my $startIdx = 0;
        if ( $proxyCount > 0 ) {
            $startIdx = $self->{ipHashVal} % $proxyCount;
            if ( $startIdx > 0 ) {
                my @headProxy = splice( @proxyList, 0, $startIdx );
                push( @proxyList, @headProxy );
            }
        }

        my $loopCount = 1;
        while (1) {
            foreach my $proxy (@proxyList) {
                my @address = split( /:/, $proxy );
                for ( my $i = 1 ; $i < 3 ; $i++ ) {
                    if ( defined($listenAddr) and $listenAddr eq '0.0.0.0' ) {
                        $socket = IO::Socket::INET->new(
                            PeerAddr => $address[0],
                            PeerPort => $address[1],
                            Proto    => "tcp",
                            Type     => $socketType
                        );
                    }
                    else {
                        $socket = IO::Socket::INET->new(
                            LocalAddr => $listenAddr,
                            PeerAddr  => $address[0],
                            PeerPort  => $address[1],
                            Proto     => "tcp",
                            Type      => $socketType
                        );
                    }

                    my $_dont_inherit = $self->{_dont_inherit};
                    if ( defined($_dont_inherit) ) {
                        &$_dont_inherit($socket);
                    }

                    if ( not defined($socket) ) {
                        $tagent->log("WARN: connect to server @address failed.\n");
                        sleep( 20 * $i + rand( 20 * $i ) );
                    }
                    else {
                        last;
                    }
                }

                if ( defined($socket) ) {
                    last;
                }
            }

            if ( defined($socket) ) {
                $tagent->log( 'INFO: server ' . $socket->peerhost() . ':' . $socket->peerport() . " connected.\n" );
                last;
            }
            else {
                $tagent->log("ERROR: connect to server $group failed:$!\n");
                sleep( 3 * $loopCount + rand( 3 * $loopCount ) );
            }
            $loopCount = $loopCount + 1;
        }
    }
    return $socket;
}

sub _resetCred {
    my ($self) = @_;
    my $config = $self->{config}->{_};
    my $tagent = $self->{tagent};

    my $newPass          = $self->randPass();
    my $authKeyEncrypted = '{ENCRYPTED}' . _rc4_encrypt_hex( $self->{MY_KEY}, $newPass );

    $config->{'credential'} = $authKeyEncrypted;
    if ( not $self->{config}->write( $self->{confFile} ) ) {
        $tagent->log("WARN:  Update config file failed $!\n");
    }

    $self->_reload();
}

sub _reload {
    my ($self) = @_;

    my $ppid;

    if ( $self->{ostype} eq 'windows' ) {
        my $confBase = $ENV{TAGENT_HOME};
        my $progName = $FindBin::Script;
        my $pidFile  = "$confBase/logs/$progName.pid";
        my $pidFh;
        open( $pidFh, "<$pidFile" );
        if ( defined($pidFh) ) {
            my $allPid = <$pidFh>;
            close($pidFh);

            my @pids = split( /\s+/, $allPid );
            $ppid = $pids[0];
        }

        #kill($ppid);
        system("taskkill /F /PID $ppid");
    }
    else {
        $ppid = getppid();
        $self->{tagent}->log("INFO: signal process:$ppid to reload.\n");
        kill( 'USR1', $ppid );
    }

    exit(127);
}

sub _execModuleAction {
    my ( $self, $app, $action ) = @_;
    my $tagent = $self->{tagent};

    my $appsConf = $self->{appsConf};
    my $ostype   = $self->{ostype};
    my $appConf  = $appsConf->{$app};

    my $myAppConf  = $appConf->{$ostype};
    my $actionConf = $myAppConf->{$action};

    my $interpreter;
    if ( not defined($actionConf) ) {
        next;
    }

    $interpreter = $actionConf->{interpreter};
    if ( $interpreter eq '' ) {
        undef($interpreter);
    }

    my $confDir = $self->{confDir};
    my $logFile = "$confDir/../logs/${app}_${action}.log";

    my $cmd;
    if ( $ostype eq 'windows' ) {
        if ( not defined($interpreter) or $interpreter =~ /^\s*cmd\s*$/ ) {
            $interpreter = 'cmd /c';
        }

        my $extName = $self->_getWinScriptExt($interpreter);
        $cmd = "\"$confDir/managed/$app/$action$extName\" > \"$logFile\" 2>&1";
        $cmd =~ s/\//\\/g;
        $cmd = "$interpreter $cmd";
    }
    else {
        if ( not defined($interpreter) ) {
            $interpreter = 'sh';
        }
        $cmd = "$interpreter '$confDir/managed/$app/$action' > '$logFile' 2>&1";
    }

    my $ret = 0;
    my $pipe;
    my $pid = open( $pipe, '-|', $cmd );
    if ( defined($pipe) ) {
        my $loopCount = 300;
        while ( waitpid( $pid, WNOHANG ) == 0 and $loopCount > 0 ) {
            sleep(1);
            $loopCount--;
        }

        if ( $loopCount <= 0 ) {
            if ( $ostype eq 'windows' ) {
                system("TASKKILL /F /T /PID $pid");
            }
            else {
                kill( 'KILL', $pid );
            }
        }
        else {
            $ret = $?;
        }

        if ( $ret ne 0 ) {
            $tagent->log("ERROR: execute app:$app action:$action cmd:$cmd, ret:$ret failed.\n");
        }
        close($pipe);
    }
    else {
        $tagent->log("ERROR: lauch app:$app action:$action cmd:$cmd failed:$!\n");
    }
}

sub _upgrade {
    my ($self) = @_;

    # 解压文件
    # system("tar -zxvf  /opt/tagent/run/root/tmp/tagent.tar.gz /opt/tmp/");

}

sub _updateAppsConf {
    my ( $self, $data ) = @_;
    my $tagent   = $self->{tagent};
    my $appsConf = $data->{apps};
    my $appsMd5  = $data->{md5};
    my $ostype   = $self->{ostype};
    my $confDir  = $self->{confDir};

    if ( not -e "$confDir/managed" ) {
        mkdir("$confDir/managed");
    }

    my $appsConfMd5File = "$confDir/managed/apps.json.md5";
    my $appsConfFile    = "$confDir/managed/apps.json";

    my $file = IO::File->new(">$appsConfFile");
    if ( defined($file) ) {
        print $file ( to_json($appsConf) );
        $file->close();
    }

    my @keysTmp = ( 'monitor', 'start', 'stop', 'install', 'uninstall' );
    foreach my $app ( keys(%$appsConf) ) {

        my $appConf     = $appsConf->{$app};
        my $defaultConf = $appConf->{default};
        my $myOsConf    = $appConf->{$ostype};

        if ( not defined($myOsConf) ) {
            $appConf->{$ostype} = $defaultConf;
            $myOsConf = $defaultConf;
        }
        else {
            foreach my $key ( keys(%$defaultConf) ) {
                if ( not defined( $myOsConf->{$key} ) ) {
                    $myOsConf->{$key} = $defaultConf->{$key};
                }
            }
        }

        my %validKeys  = map { $_ => 1 } @keysTmp, keys(%$myOsConf);
        my @scriptKeys = keys(%validKeys);

        foreach my $scriptKey (@scriptKeys) {
            my $interpreter;
            my $content     = '';
            my $myActionObj = $myOsConf->{$scriptKey};
            if ( defined($myActionObj) ) {
                if ( ref($myActionObj) eq 'HASH' ) {
                    $content     = $myActionObj->{script};
                    $interpreter = $myActionObj->{interpreter};
                }
                else {
                    $tagent->log("ERROR: $app action($scriptKey) defined not in json format: $myActionObj\n");
                }

                if ( not defined($interpreter) or $interpreter eq '' ) {
                    $tagent->log("ERROR: $app action($scriptKey) has no attribute:interpreter\n");
                }
            }

            if ( not defined($interpreter) or $interpreter eq '' ) {
                if ( $ostype eq 'windows' ) {
                    $interpreter = 'cmd';
                }
                else {
                    $interpreter = 'sh';
                }
            }

            #$tagent->log("DEBUG: CREATE $scriptKey  FILE START , conetnt is $content  \n");
            my $scriptDir = "$confDir/managed/$app";
            if ( not -e $scriptDir ) {
                mkdir($scriptDir);
            }
            else {
                foreach my $oldFile ( glob("$scriptDir/$scriptKey.*") ) {
                    unlink($oldFile);
                }
                if ( -e "$scriptDir/$scriptKey" ) {
                    unlink("$scriptDir/$scriptKey");
                }
            }

            my $extName = '';
            if ( $ostype eq 'windows' ) {
                $extName = $self->_getWinScriptExt($interpreter);
            }

            my $file = IO::File->new(">$scriptDir/$scriptKey$extName");
            if ( defined($file) ) {
                print $file ($content);
                $file->close();
            }

        }
    }

    foreach my $appDir ( glob("$confDir/managed/*") ) {
        my $appSubDir = basename($appDir);
        if ( $appSubDir ne '.' and $appSubDir ne '..' and -d $appDir ) {
            if ( not defined( $appsConf->{$appSubDir} ) ) {
                rmdir($appDir);
            }
        }
    }

    #$tagent->log("DEBUG: CREATE md5  FILE START , conetnt is $appsMd5  \n");
    my $md5File = IO::File->new(">$appsConfMd5File");
    if ( defined($md5File) ) {
        print $md5File ($appsMd5);
        $md5File->close();
    }
}

sub _updategroup {
    my ( $self, $seqNo, $proxyGroupId, $cmdobj ) = @_;
    my $config = $self->{config}->{_};
    my $tagent = $self->{tagent};
    if ( $cmdobj->{'isNew'} eq '1' ) {
        my $confChanged = 0;

        my $proxyGroups    = $self->{proxyGroups};
        my $proxyGroupConf = $$proxyGroups[$seqNo];

        my $newProxyGroupsConf = $cmdobj->{'groupinfo'};
        if ( $newProxyGroupsConf ne $proxyGroupConf ) {
            $$proxyGroups[$seqNo]    = $newProxyGroupsConf;
            $config->{'proxy.group'} = join( ';', @$proxyGroups );
            $confChanged             = 1;
        }

        if ( $confChanged == 1 ) {
            $tagent->log("INFO: Proxy group changed, try to update config file...\n");
            if ( not $self->{config}->write( $self->{confFile} ) ) {
                $tagent->log("ERROR: Update config proxy group in config file failed:$!\n");
                die("Update config proxy group in config file failed:$!\n");
            }
            $tagent->log("ERROR: Update config proxy group in config file success.\n");
        }
    }
}

sub _healthCheck {
    my ( $self, $tagentCli ) = @_;
    my $config = $self->{config}->{_};

    my $ip   = '127.0.0.1';
    my $port = $config->{'listen.port'};

    my $authKeyEncrypted = $config->{'credential'};
    my $authKey          = $authKeyEncrypted;
    if ( $authKeyEncrypted =~ s/^{ENCRYPTED}\s*// ) {
        $authKey = _rc4_decrypt_hex( $self->{MY_KEY}, $authKeyEncrypted );
    }

    my $echoMsg = 'heartbeat';
    my $echoBack;

    $tagentCli->{password} = $authKey;

    eval { $echoBack = $tagentCli->echo($echoMsg); };

    if ( defined($echoBack) and $echoBack eq $echoMsg ) {
        return 1;
    }
    else {
        return 0;
    }
}

sub handleCtlCmd {
    my ( $self, $socket, $cmd ) = @_;
    my $tagent = $self->{tagent};

    $cmd =~ s/^\s+|\s$//g;
    if ( $cmd ne '' ) {
        my $cmdobj;
        eval { $cmdobj = from_json($cmd); };
        if ($@) {
            $tagent->log("ERROR: command from server not in json formant:$@\n$cmd\n");
            return;
        }

        $tagent->log( 'INFO: handle command:' . $cmdobj->{type} . "\n" );
        eval {
            if ( $cmdobj->{'type'} eq 'reload' ) {
                $self->_reload();
            }
            elsif ( $cmdobj->{'type'} eq 'resetcred' ) {
                $self->_resetCred();
            }

            #elsif ( $cmdobj->{'type'} eq 'upgrade' ) {
            #    $self->_upgrade();
            #}
            elsif ( $cmdobj->{'type'} eq 'updateAppsConf' ) {
                $tagent->log( 'INFO: update apps conf: ' . $cmdobj->{data} . "\n" );
                $self->_updateAppsConf( $cmdobj->{data} );
            }
            elsif ( $cmdobj->{'type'} eq 'moduleAction' ) {
                $tagent->log( 'INFO: execute module action: ' . $cmdobj->{moduleName} . '.' . $cmdobj->{moduleAction} . "\n" );
                $self->_execModuleAction( $cmdobj->{moduleName}, $cmdobj->{moduleAction} );
            }
            else {
                $tagent->log( 'INFO: command:' . $cmdobj->{type} . " not supported.\n" );
            }
        };
        if ($@) {
            $tagent->log( 'ERROR: handle action ' . $cmdobj->{'type'} . " failed, $@\n" );
        }
    }
}

sub getWinProcCpuAndMem {
    my ($self) = @_;
    my $wmi;

    my $pid;

    my $confBase = $ENV{TAGENT_HOME};
    my $progName = $FindBin::Script;
    my $pidFile  = "$confBase/logs/$progName.pid";

    my $pidFh;
    open( $pidFh, "<$pidFile" );
    if ( defined($pidFh) ) {
        my $allPid = <$pidFh>;
        close($pidFh);

        my @pids = split( /\s+/, $allPid );
        $pid = $pids[0];
    }

    eval( '
        use Win32::OLE;
    Win32::OLE->Option( Warn => 0 );
    $wmi = Win32::OLE->GetObject("winmgmts:{impersonationLevel=impersonate,(Debug)}!//./root/cimv2") || die ("get wmi object failed.");
        '
    );

    my $proc = $wmi->Get("Win32_Process=$pid");

    my $aCpuTime = $proc->{UserModeTime} + $proc->{KernelModeTime};
    sleep(1);
    $proc = $wmi->Get("Win32_Process=$pid");
    my $bCpuTime = $proc->{UserModeTime} + $proc->{KernelModeTime};

    my $cpuPercent = sprintf( '%.2f', ( $bCpuTime - $aCpuTime ) / $ENV{"NUMBER_OF_PROCESSORS"} / 10000000 * 100 );
    my $memSize    = sprintf( '%.2f', $proc->{WorkingSetSize} / 1024 / 1024 );

    return ( sprintf( '%.2f', $cpuPercent ), sprintf( '%.2f', $memSize ) );
}

sub getPosixProcCpuAndMem {
    my ($self)   = @_;
    my $tagent   = $self->{tagent};
    my $confBase = $ENV{TAGENT_HOME};
    my $progName = $FindBin::Script;
    my $pidFile  = "$confBase/logs/$progName.pid";
    my $pidFh;

    my $pcpu = 0;
    my $mem  = 0;

    open( $pidFh, "<$pidFile.subproc" );
    if ( defined($pidFh) ) {
        my $allPid = <$pidFh>;
        close($pidFh);

        if ( not defined($allPid) ) {
            $allPid = '';
        }

        my @pids = split( /\s+/, $allPid );
        push( @pids, $$ );

        foreach my $pid (@pids) {
            my $procInfo;
            my $cmd;
            if ( $self->{ostype} eq 'aix' ) {
                $cmd = "ps -p $pid -o pcpu,rssize |";
            }
            elsif ( $self->{ostype} eq 'hp-ux' ) {
                $cmd = "export UNIX95=1;ps -p $pid -o pcpu,sz |";
            }
            else {
                $cmd = "ps -p $pid -o pcpu,rss |";
            }

            if ( open( $procInfo, $cmd ) ) {
                my $line;
                $line = <$procInfo>;
                $line = <$procInfo>;
                if ( defined($line) ) {
                    $line =~ s/^\s+|\s+$//g;
                    if ( $line ne '' ) {
                        my ( $p, $m ) = split( /\s+/, $line );
                        $pcpu = $pcpu + sprintf( '%.2f', $p );
                        $mem  = $mem + sprintf( '%.2f', $m );
                    }
                }
            }
            close($procInfo);
        }
    }
    if ( $self->{ostype} eq 'hp-ux' ) {
        my $pageSize = 4096;
        eval {
            my $cmd = "getconf PAGESIZE |";
            my $pageInfo;
            if ( open( $pageInfo, $cmd ) ) {
                $pageSize = <$pageInfo>;
            }
        };
        if ($@) {
            $tagent->log("WARN: get page size failed, set pageSize = 4096\n");
        }
        $mem = $pageSize * $mem / 1024;
    }

    return ( sprintf( '%.2f', $pcpu ), sprintf( '%.2f', $mem / 1024 ) );
}

sub initAppStatus {
    my ($self) = @_;
    my $appStatus = {};
    $appStatus->{status}           = '';
    $appStatus->{'mon-fail-count'} = 0;
    $appStatus->{'fail-run-count'} = 0;
    $appStatus->{'over-run-count'} = 0;

    return $appStatus;
}

sub runCmd {
    my $self = shift;

    my $ostype = $self->{ostype};

    my $pid;
    my $pipe;

    if ( $ostype eq 'windows' ) {
        $pid = open( $pipe, '-|', @_ );
    }
    else {
        $pid = open( $pipe, '-|', @_ );
    }

    return ( $pid, $pipe );
}

sub checkRule {
    my ( $self, $app, $appStatus ) = @_;
    my $tagent      = $self->{tagent};
    my $ostype      = $self->{ostype};
    my $appsConf    = $self->{appsConf};
    my $restartRule = $appsConf->{$app}->{$ostype}->{'restart-rule'};

    #$tagent->log("DEBUG: restart-rule:" . to_json($restartRule) . "\n");

    if ( not defined($restartRule) ) {
        return ( undef, undef );
    }

    my $needRestart   = 0;
    my $matchSchedule = 0;
    my $interval      = $self->{loopInterval};

    if ( int( $restartRule->{'when-over-run'} ) > 0 and $appStatus->{'over-run-count'} >= int( $restartRule->{'when-over-run'} ) ) {
        $tagent->log("WARN: $app continouse over-run count:$appStatus->{'over-run-count'}, try to restart.\n");
        $appStatus->{'over-run-count'} = 0;
        $needRestart = 1;
    }

    if ( $needRestart == 0 and int( $restartRule->{'when-fail-run'} ) > 0 and $appStatus->{'fail-run-count'} >= int( $restartRule->{'when-fail-run'} ) ) {
        $tagent->log("WARN: $app continouse fail-run count:$appStatus->{'fail-run-count'}, try to restart.\n");
        $appStatus->{'fail-run-count'} = 0;
        $needRestart = 1;
    }

    if ( $needRestart == 0 and $restartRule->{'when-down'} eq 'true' and $appStatus->{status} eq 'down' ) {
        $tagent->log("WARN: $app is down, try to restart.\n");
        $needRestart = 1;
    }

    if ( $needRestart == 0 ) {
        $matchSchedule = 1;

        my $monthDayMatched = 1;
        my $hourMatched     = 1;
        my $weekDayMatched  = 1;
        my $minuteMatched   = 1;

        my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime();
        $year = $year + 1900;
        $mon  = $mon + 1;

        my $whenWeekDay = $restartRule->{'when-week-day'};
        if ( defined($whenWeekDay) ) {
            if ( $whenWeekDay ne '*' and $whenWeekDay !~ /^$wday|\s$wday\s|$wday$/ ) {
                $weekDayMatched = 0;
                $matchSchedule  = 0;
            }
        }

        if ( $matchSchedule == 1 ) {
            my $whenMonthDay = $restartRule->{'when-month-day'};
            if ( defined($whenMonthDay) ) {
                if ( $whenMonthDay ne '*' and $whenMonthDay !~ /^$mday|\s$mday\s|$mday$/ ) {
                    $monthDayMatched = 0;
                    $matchSchedule   = 0;
                }
            }
        }

        if ( $matchSchedule == 1 ) {
            my $whenHour = $restartRule->{'when-hour'};
            if ( defined($whenHour) ) {
                if ( $whenHour ne '*' and $whenHour !~ /^$hour|\s$hour\s|$hour$/ ) {
                    $hourMatched   = 0;
                    $matchSchedule = 0;
                }
            }
        }

        if ( $matchSchedule == 1 ) {
            my $whenMinute = $restartRule->{'when-minute'};
            if ( defined($whenMinute) ) {
                if ( $whenMinute ne '*' ) {
                    my @whenMinutes = split( /\s+/, $whenMinute );
                    foreach my $aMin (@whenMinutes) {
                        if ( int($aMin) - $interval < $min or int($aMin) + $interval > $min ) {
                            $minuteMatched = 0;
                            $matchSchedule = 0;
                        }
                    }
                }
            }
        }
    }

    if ( $matchSchedule == 1 ) {
        $tagent->log("INFO: $app match restart schedule, try to restart.\n");
    }

    if ( $needRestart == 1 or $matchSchedule == 1 ) {
        my $myAppConf = $appsConf->{$app}->{$ostype};
        my $stopConf  = $myAppConf->{stop};
        my $startConf = $myAppConf->{start};

        if ( not defined($stopConf) or not defined($startConf) ) {
            return ( undef, undef );
        }

        my $stopInterpreter = $stopConf->{interpreter};
        if ( $stopInterpreter eq '' ) {
            undef($stopInterpreter);
        }

        my $startInterpreter = $startConf->{interpreter};
        if ( $startInterpreter eq '' ) {
            undef($startInterpreter);
        }

        my $confDir = $self->{confDir};

        my $restartCmd;
        if ( $ostype eq 'windows' ) {
            if ( not defined($stopInterpreter) or $stopInterpreter =~ /^\s*cmd\s*$/ ) {
                $stopInterpreter = 'cmd /c';
            }
            if ( not defined($startInterpreter) or $startInterpreter =~ /^\s*cmd\s*$/ ) {
                $startInterpreter = 'cmd /c';
            }

            my $stopExtName  = $self->_getWinScriptExt($stopInterpreter);
            my $startExtName = $self->_getWinScriptExt($startInterpreter);

            my $winConfDir = $confDir;
            $winConfDir =~ s/\//\\/g;
            $restartCmd = "$stopInterpreter \"$confDir\\managed\\$app\\stop$stopExtName\" 2>&1 && $startInterpreter \"$confDir\\managed\\$app\\start$startExtName\" 2>&1";
        }
        else {
            if ( not defined($stopInterpreter) ) {
                $stopInterpreter = 'sh';
            }
            if ( not defined($startInterpreter) ) {
                $startInterpreter = 'sh';
            }

            $restartCmd = "$stopInterpreter '$confDir/managed/$app/stop' 2>&1 && $startInterpreter '$confDir/managed/$app/start' 2>&1";
        }

        $tagent->log("INFO: try to restart $app:$restartCmd\n");

        #my $pid = open( $pipe, "$restartCmd |" );
        my ( $pid, $pipe ) = $self->runCmd($restartCmd);

        return ( $pid, $pipe );
    }

    return ( undef, undef );
}

sub monOtherApps {
    my ($self) = @_;

    my $tagent = $self->{tagent};

    my $appsConfMd5 = $self->{appsConfMd5};
    my $confDir     = $self->{confDir};

    my $appsConf = $self->{appsConf};
    if ( not defined($appsConf) ) {
        $appsConf = {};
    }

    my $appsConfMd5File = "$confDir/managed/apps.json.md5";

    if ( -f $appsConfMd5File ) {
        my $appsConfFile = "$confDir/managed/apps.json";
        if ( -f $appsConfFile ) {
            eval {
                my $newestAppsConfMd5 = $self->getFileContent($appsConfMd5File);
                if ( $newestAppsConfMd5 ne $appsConfMd5 ) {
                    $tagent->log("INFO: apps config changed, try to reload config...\n");
                    my $appsJson = $self->getFileContent($appsConfFile);
                    $appsConf = from_json($appsJson);
                    my $ostype = $self->{ostype};

                    foreach my $app ( keys(%$appsConf) ) {

                        my $appConf     = $appsConf->{$app};
                        my $defaultConf = $appConf->{default};
                        my $myOsConf    = $appConf->{$ostype};

                        if ( not defined($myOsConf) ) {
                            $appConf->{$ostype} = $defaultConf;
                        }
                        else {
                            foreach my $key ( keys(%$defaultConf) ) {
                                if ( not defined( $myOsConf->{$key} ) ) {
                                    $myOsConf->{$key} = $defaultConf->{$key};
                                }
                            }
                        }
                    }

                    $self->{appsConf}    = $appsConf;
                    $self->{appsConfMd5} = $newestAppsConfMd5;
                    $tagent->log("INFO: apps config changed, reloaded.\n");
                }
            };
            if ($@) {
                $tagent->log("WARN: parse json file:$appsConfFile failed.\n");
            }
        }
    }

    my @apps   = keys(%$appsConf);
    my $ostype = $self->{ostype};

    my $pid2App      = {};
    my $pid2Pipe     = {};
    my $allAppStatus = $self->{appsStatus};

    my $restartPid2Pipe = {};
    my $restartPid2App  = {};

    my $pidKilled = {};

    foreach my $app (@apps) {
        my $appConf = $appsConf->{$app};

        my $myAppConf = $appConf->{$ostype};
        my $monConf   = $myAppConf->{monitor};
        my $interpreter;
        if ( not defined($monConf) ) {
            next;
        }

        $interpreter = $monConf->{interpreter};
        if ( $interpreter eq '' ) {
            undef($interpreter);
        }

        my $monCmd;
        if ( $ostype eq 'windows' ) {
            if ( not defined($interpreter) or $interpreter =~ /^\s*cmd\s*$/ ) {
                $interpreter = 'cmd /c';
            }
            my $extName = $self->_getWinScriptExt($interpreter);
            $monCmd = "\"$confDir/managed/$app/monitor$extName\" 2>&1";
            $monCmd =~ s/\//\\/g;
            $monCmd = "$interpreter $monCmd";
        }
        else {
            if ( not defined($interpreter) ) {
                $interpreter = 'sh';
            }
            $monCmd = "$interpreter '$confDir/managed/$app/monitor' 2>&1";
        }

        #$tagent->log("DEBUG: mon cmd : $monCmd  \n");
        #my $pid = open( $pipe, "$monCmd |" );
        my ( $pid, $pipe ) = $self->runCmd($monCmd);

        if ( defined($pid) ) {
            $pid2App->{$pid}  = $app;
            $pid2Pipe->{$pid} = $pipe;
        }
    }

    my $startTime = time();

    while ( %$pid2App or %$restartPid2App ) {
        my $isTimeout = 0;
        my $timeOut   = 60;
        my $childPid;
        do {
            $childPid = waitpid( -1, WNOHANG );
            if ( $childPid > 0 ) {
                my $exitStatus = $?;

                my $pipe = $pid2Pipe->{$childPid};

                if ( not defined($pipe) ) {
                    my $restartPipe = $restartPid2Pipe->{$childPid};
                    my $restartApp  = $restartPid2App->{$childPid};

                    if ( defined($restartPipe) ) {
                        if ( $exitStatus == 0 ) {
                            $tagent->log("INFO: restart $restartApp success.");
                        }
                        else {
                            my $errMsg;
                            my $line;
                            while ( $line = <$restartPipe> ) {
                                $errMsg = $errMsg . $line;
                            }

                            if ( $isTimeout == 0 ) {
                                $tagent->log("ERROR: restart $restartApp failed:\n$errMsg");
                            }
                            else {
                                $tagent->log("ERROR: restart $restartApp time out:\n$errMsg");
                            }
                        }

                        close($restartPipe);
                        delete( $restartPid2Pipe->{$childPid} );
                        delete( $restartPid2App->{$childPid} );
                    }
                    next;
                }

                my $app       = $pid2App->{$childPid};
                my $appStatus = $allAppStatus->{$app};
                if ( not defined($appStatus) ) {
                    $appStatus = $self->initAppStatus();
                }

                my $line;
                my $errMsg = '';
                my $key;
                my $val;
                while ( $line = <$pipe> ) {
                    if ( $line =~ /\s*(\w+)\s*[=:]\s*([^\s]+)/ ) {
                        $key = $1;
                        $val = $2;
                        if ( $key eq 'status' ) {
                            if ( $val eq 'over-run' ) {
                                $appStatus->{'fail-run-count'} = 0;
                                if ( $appStatus->{status} eq 'over-run' ) {
                                    $appStatus->{'over-run-count'} = 1 + $appStatus->{'over-run-count'};
                                }
                                else {
                                    $appStatus->{'over-run-count'} = 1;
                                }
                            }
                            elsif ( $val eq 'fail-run' ) {
                                $appStatus->{'over-run-count'} = 0;
                                if ( $appStatus->{status} eq 'fail-run' ) {
                                    $appStatus->{'fail-run-count'} = 1 + $appStatus->{'fail-run-count'};
                                }
                                else {
                                    $appStatus->{'fail-run-count'} = 1;
                                }
                            }
                            else {
                                $appStatus->{'over-run-count'} = 0;
                                $appStatus->{'fail-run-count'} = 0;
                            }
                        }

                        $appStatus->{$key} = $val;
                    }
                    if ( $exitStatus != 0 ) {
                        $errMsg = $errMsg . $line;
                    }
                }

                if ( $exitStatus != 0 ) {
                    if ( $isTimeout == 0 ) {
                        $tagent->log("ERROR: execute mon for $app failed:\n$errMsg\n");
                    }
                    else {
                        $tagent->log("ERROR: execute mon for $app > $timeOut, time out.\n$errMsg\n");
                    }

                    if ( $appStatus->{status} eq 'mon-fail' ) {
                        $appStatus->{'mon-fail-count'} = 1 + $appStatus->{'mon-fail-count'};
                    }
                    else {
                        $appStatus->{'mon-fail-count'} = 1;
                    }
                    $appStatus->{status} = 'mon-fail';
                }
                else {
                    $tagent->log("INFO: execute mon for $app succeed.\n");
                    $appStatus->{'mon-fail-count'} = 0;
                }

                $allAppStatus->{$app} = $appStatus;

                close($pipe);
                delete( $pid2Pipe->{$childPid} );
                delete( $pid2App->{$childPid} );

                my ( $restartPid, $restartPipe ) = $self->checkRule( $app, $appStatus );
                if ( defined($restartPid) ) {
                    $restartPid2App->{$restartPid}  = $app;
                    $restartPid2Pipe->{$restartPid} = $restartPipe;
                }
            }
            else {
                if ( time() - $startTime > $timeOut ) {
                    $isTimeout = 1;
                }
                else {
                    sleep(1);
                }
            }

            if ( $isTimeout == 1 ) {
                my $timeOutPid;
                foreach $timeOutPid ( keys(%$pid2Pipe) ) {
                    if ( not defined( $pidKilled->{$timeOutPid} ) ) {
                        $tagent->log("WARN: timeout, kill pid:$timeOutPid.\n");
                        my $appStatus = $self->initAppStatus();
                        if ( $self->{ostype} eq 'windows' ) {
                            system("TASKKILL /F /T /PID $timeOutPid");
                        }
                        else {
                            kill( 'KILL', $timeOutPid );
                        }
                        $pidKilled->{$timeOutPid} = 1;
                    }
                }

                foreach $timeOutPid ( keys(%$restartPid2Pipe) ) {
                    if ( not defined( $pidKilled->{$timeOutPid} ) ) {
                        $tagent->log("WARN: timeout, kill pid:$timeOutPid.\n");
                        if ( $self->{ostype} eq 'windows' ) {
                            system("TASKKILL /F /T /PID $timeOutPid");
                        }
                        else {
                            kill( 'KILL', $timeOutPid );
                        }
                        $pidKilled->{$timeOutPid} = 1;
                    }
                }
            }
        } while ( $childPid != -1 );
    }

    return $allAppStatus;
}

sub refreshPool {
    my ($self) = @_;

    my $proxyGroups      = $self->{proxyGroups};
    my $proxyGroupIds    = $self->{proxyGroupIds};
    my $connsMap         = $self->{connsMap};
    my $proxyGroupIdsMap = {};
    for ( my $i = 0 ; $i < scalar(@$proxyGroups) ; $i++ ) {
        my $proxyGroupId = $$proxyGroupIds[$i];
        $proxyGroupIdsMap->{$proxyGroupId} = 1;
        my $proxyGroup = $$proxyGroups[$i];
        my $oldConn    = $connsMap->{$proxyGroupId};
        if ( not defined($oldConn) ) {
            my $conn = $self->getConnection($proxyGroup);
            if ( defined($conn) ) {
                $connsMap->{$proxyGroupId} = $conn;
            }
        }
    }
    foreach my $connId ( keys(%$connsMap) ) {
        if ( not defined( $proxyGroupIdsMap->{$connId} ) ) {
            delete( $connsMap->{$connId} );
        }
    }
}

sub createConnPool {
    my ($self) = @_;

    my $loopInterval = $self->{loopInterval};
    if ( $loopInterval <= 15 ) {
        $loopInterval = 180;
        $self->{loopInterval} = $loopInterval;
    }

    $self->refreshPool();
}

sub doHeartBeat {
    my ( $self, $seqNo, $proxyGroupId, $conn, $statusInfo ) = @_;

    my $tagent = $self->{tagent};
    my $config = $self->{config}->{_};

    my $peerHost = $conn->peerhost();
    my $peerPort = $conn->peerport();
    my $peerAddr = "$peerHost:$peerPort";

    my $proxyGroups = $self->{proxyGroups};
    $statusInfo->{proxyGroup} = $$proxyGroups[$seqNo];
    $statusInfo->{proxyIp}    = $peerHost;
    $statusInfo->{proxyPort}  = $peerPort;

    my $tagentIds = $self->{tagentIds};
    my $tagentId  = $$tagentIds[$seqNo];
    $statusInfo->{agentId} = $tagentId;

    my $tenants = $self->{tenants};
    $statusInfo->{tenant} = $$tenants[$seqNo];

    $conn->syswrite( to_json($statusInfo) . "\n" );
    $tagent->log( "INFO: Send heartbeat info:" . to_json($statusInfo) . " to $peerAddr\n" );

    my $isFailed    = 0;
    my $refreshConn = 0;
    my $sel         = new IO::Select($conn);
    if ( $sel->can_read(60) ) {
        my $buf = readline($conn);
        $tagent->log("INFO: Recive server $peerAddr Response: $buf\n");

        if ( not defined($buf) ) {
            $isFailed = 1;
            $tagent->log("WARN: server connection $peerAddr failed:$!\n");
        }
        else {
            $buf =~ s/^\s+|\s+$//g;
            if ( $buf ne '' ) {
                my $resp;
                eval { $resp = from_json($buf); };

                if ($@) {
                    $tagent->log("ERROR: server $peerAddr heartbeat response not in json format:$@\n$buf\n");
                }
                else {
                    if ( defined( $resp->{Status} ) and $resp->{Status} ne 'OK' ) {
                        $isFailed = 1;
                        $tagent->log("WARN: get server $peerAddr error:$buf\n");
                    }
                    if ( defined( $resp->{type} ) and $resp->{type} eq 'updategroup' ) {
                        my $proxyGroups = $self->{proxyGroups};
                        my $respProxys  = $resp->{'groupinfo'};
                        if ( $$proxyGroups[$seqNo] ne $respProxys and $respProxys ne '' ) {
                            $tagent->log("INFO: Update $peerAddr reponsed proxy group[$seqNo] to:$respProxys and reload.\n");
                            $self->_updategroup( $seqNo, $proxyGroupId, $resp );
                            $$proxyGroups[$seqNo] = $respProxys;
                            $refreshConn = 1;
                        }
                    }
                }
            }
        }
    }
    else {
        $isFailed = 1;
        $tagent->log("WARN: get server $peerAddr response failed.\n");
    }

    if ( $isFailed == 1 or $refreshConn == 1 ) {
        $conn->shutdown(2);

        #delete closed connection
        my $connsMap = $self->{connsMap};
        delete( $connsMap->{$proxyGroupId} );
    }
}

sub mainLoop {
    my ($self) = @_;

    my $tagent       = $self->{tagent};
    my $loopInterval = $self->{loopInterval};

    my $config = $self->{config}->{_};
    my $port   = $config->{'listen.port'};
    my $ip     = '127.0.0.1';

    my $authKeyEncrypted = $config->{'credential'};
    my $authKey          = $authKeyEncrypted;
    if ( $authKeyEncrypted =~ s/^{ENCRYPTED}\s*// ) {
        $authKey = _rc4_decrypt_hex( $self->{MY_KEY}, $authKeyEncrypted );
    }
    my $tagentCli = TagentClient->new( $ip, $port, $authKey );

    $self->createConnPool();

    while (1) {
        $self->register();

        my $iniConfig = Config::Tiny->read( $self->{confFile} );
        $self->{config} = $iniConfig;
        my $config = $iniConfig->{_};

        my $port       = $config->{'listen.port'};
        my $proxyGroup = $config->{'proxy.group'};

        my ( $pcpu, $mem );
        my $connsMap = $self->{connsMap};
        my @conns    = values(%$connsMap);
        if ( not @conns ) {
            $tagent->log("WARN: No heartbeat connection.\n");
            sleep(10);
            $self->refreshPool();
            next;
        }

        if ( $self->{ostype} eq 'windows' ) {
            ( $pcpu, $mem ) = $self->getWinProcCpuAndMem();
        }
        else {
            ( $pcpu, $mem ) = $self->getPosixProcCpuAndMem();
        }

        my $status      = 'working';
        my $isAgentWork = $self->_healthCheck($tagentCli);
        if ( $isAgentWork == 0 ) {
            $status = 'stuck';
            $tagent->log("ERROR: health check failed, try to reload.\n");
            $self->_reload();
        }

        if ( $self->{hasTagentId} == 1 ) {
            my $statusInfo = {};
            my $ipString   = $self->collectIp();
            $statusInfo->{type}     = 'monitor';
            $statusInfo->{port}     = int($port);
            $statusInfo->{ipString} = $ipString;
            $statusInfo->{pcpu}     = $pcpu * 1;
            $statusInfo->{mem}      = $mem * 1;
            $statusInfo->{status}   = $status;
            $statusInfo->{version}  = getVersion();

            my $mgmtIp = $self->getMgmtIp($ipString);
            if ( defined($mgmtIp) and $mgmtIp ne '' ) {
                $tagent->log("INFO: get tagent manage subnet register ip: $mgmtIp .\n");
                $statusInfo->{mgmtIp} = $mgmtIp;
            }

            eval {
                $tagent->log("INFO: begin to check managed app.\n");
                my $allAppStatus = $self->monOtherApps();
                $tagent->log("INFO: check managed app finished.\n");
                $statusInfo->{appsInfo} = $allAppStatus;
            };
            if ($@) {
                $tagent->log("ERROR: $@\n");
            }

            my $proxyGroupIds = $self->{proxyGroupIds};
            my $connsMap      = $self->{connsMap};
            for ( my $i = 0 ; $i < scalar(@$proxyGroupIds) ; $i++ ) {
                my $proxyGroupId = $$proxyGroupIds[$i];
                my $conn         = $connsMap->{$proxyGroupId};
                $statusInfo->{proxyGroupId} = $proxyGroupId;
                $self->doHeartBeat( $i, $proxyGroupId, $conn, $statusInfo );
            }
        }

        @conns = values(%$connsMap);
        if ( not @conns ) {
            $tagent->log("WARN: No heartbeat connection.\n");
            sleep(10);
            next;
        }

        $loopInterval = $self->{loopInterval};
        my $sel   = IO::Select->new(@conns);
        my @ready = $sel->can_read( $loopInterval + int( rand(7) ) );
        foreach my $conn (@ready) {
            my $cmd = readline($conn);

            if ( not defined($cmd) and $!{EINTR} ) {
                next;
            }

            if ( not defined($cmd) ) {
                $tagent->log( 'WARN: server connection ' . $conn->peerhost() . ':' . $conn->peerport() . " failed:$!\n" );
                $conn->shutdown(2);

                #delete closed connection
                while ( my ( $proxyGroupId, $proxyConn ) = each %$connsMap ) {
                    if ( $proxyConn == $conn ) {
                        delete( $connsMap->{$proxyGroupId} );
                    }
                }
                next;
            }

            $self->handleCtlCmd( $conn, $cmd );
        }
        $self->refreshPool();
    }
}

1;
