package Carp;

# On one line so MakeMaker will see it.
use Carp;  our $VERSION = $Carp::VERSION;

1;

# Most of the machinery of Carp used to be there.
# It has been moved in Carp.pm now, but this placeholder remains for
# the benefit of modules that like to preload Carp::Heavy directly.
