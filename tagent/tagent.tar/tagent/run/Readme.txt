Config Home dirs for tagent per user
